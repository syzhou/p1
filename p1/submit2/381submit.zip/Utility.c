#include "Utility.h"
#include "Person.h"
#include "Ordered_container.h"

#include <stdlib.h>
#include <string.h>

/* Allocate the memory for the new string and copy the source string
 * to the destination string.
 */
char* strAllocCpy(const char* source) {
	char* destination = malloc(strlen(source) + 1);
	strcpy(destination, source);
	return destination;
}

/* Comparison function for people structure.
 */
int comparePeople (const void* data_ptr1, const void* data_ptr2) {
	struct Person* person1 = (struct Person*) data_ptr1;
	struct Person* person2 = (struct Person*) data_ptr2;
	return strcmp(get_Person_lastname(person1), get_Person_lastname(person2));

}

/*Find a person by lastname and returns a pointer to the person structure.
 * Returns NULL if not found.
 * The function takes the pointer to the ordered containter and the lastname
 * as parameters.
 */
struct Person *findPersonByLastname (const struct Ordered_container* people, char* lastname) {
	struct Person* soughtForPerson = create_Person(NULL, lastname, NULL);
	void *itemPtr = OC_find_item(people, (void*) soughtForPerson);
	destroy_Person(soughtForPerson);
	return OC_get_data_ptr(itemPtr);
}

/*Add a person to an ordered container. Return 0 if successful.
 * Don't add to the container and return 1 if that person already exist.
 */
int addPersonIfNotExist(const struct Person* person_ptr, struct Ordered_container* people) {
	if (OC_find_item(people, (void*)person_ptr)) {
		return 1;
	}
	OC_insert(people, (void*)person_ptr);
	return 0;
}

/*Remove a person from an ordered container.
 * Return 0 if sucessful.
 * Don't remove and returns non-zero if that person is not present.
 */
int removePersonIfExist(const struct Person* person_ptr, struct Ordered_container* people) {
	void *itemPtr = OC_find_item(people, (void*)person_ptr);
	if (itemPtr) {
		OC_delete_item(people, itemPtr);
		return 0;
	} else {
		return 1;
	}
}


